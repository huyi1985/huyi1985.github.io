<?php
/**
 * Created by PhpStorm.
 * User: huyi07
 * Date: 2018/9/13
 * Time: 3:46 PM
 */

class Validator
{
    /**
     * @param \Validator\Constraint $constraint
     * @param $value
     * @param $errorMsg
     * @return bool
     *
    │71     static void php_zval_filter(zval *value, zend_long filter, zend_long flags, zval *options, char* charset, zend_bool copy) /* {{{ │
    │72     {                                                                                                                                │
    │73             filter_list_entry  filter_func;                                                                                          │
    │74                                                                                                                                      │
    >│75             filter_func = php_find_filter(filter);
    >│77             if (!filter_func.id) {                                                                                                   │
    │78                     // Find default filter                                                                                        │
    │79                     filter_func = php_find_filter(FILTER_DEFAULT);                                                                   │
    │80             }
     */
    public static function validate(\Validator\Constraint $constraint, $value, &$errorMsg)
    {
        // @todo avoid typo
        $success = $constraint->evaluate($value);

        if (!$success) {
            $errorMsg = $constraint->failureDescription($value);
        }

        return $success;
    }
}