<?php
namespace Validator;

class IsStringEqual extends Constraint
{
    /**
     * @var mixed
     */
    private $value;

    /**
     * @var bool
     */
    private $ignoreCase;

    public function __construct($value, bool $ignoreCase = false)
    {
        parent::__construct();

        $this->value        = $value;
        $this->ignoreCase   = $ignoreCase;
    }

    public function matches($other): bool
    {
        if ($this->ignoreCase) {
            return strcasecmp($this->value, $other) === 0;
        }

        return strcmp($this->value, $other) === 0;
    }


    public function failureDescription(): string
    {
        return \sprintf(
            "'%s' is not equal to '%s'",
            $this->other,
            $this->value
        );
    }
}
