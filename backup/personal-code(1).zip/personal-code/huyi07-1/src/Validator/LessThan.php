<?php

namespace Validator;

class LessThan extends Constraint
{
    /**
     * @var float|int
     */
    private $value;

    /**
     * @param float|int $value
     */
    public function __construct($value)
    {
        if (!is_int($value) && !is_float($value)) {
            throw new \InvalidArgumentException("Only support int or float");
        }
        parent::__construct();

        $this->value = $value;
    }

    public function failureDescription(): string
    {
        return (string) $this->other . ' is not less than ' . $this->value;
    }

    /**
     * @param mixed $other
     * @return bool
     */
    protected function matches($other): bool
    {
        if (!is_int($other) && !is_float($other)) {
            throw new \InvalidArgumentException("Only support int or float");
        }

        return $this->value > $other;
    }
}
