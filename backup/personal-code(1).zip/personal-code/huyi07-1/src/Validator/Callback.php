<?php

namespace Validator;

/**
 * Constraint that evaluates against a specified closure.
 */
class Callback extends Constraint
{
    /**
     * @var callable
     */
    private $callback;

    public function __construct(callable $callback)
    {
        parent::__construct();

        $this->callback = $callback;
    }

    /**
     * Returns a string representation of the constraint.
     */
    public function failureDescription(): string
    {
        return 'does not accepted by specified callback';
    }

    /**
     * Evaluates the constraint for parameter $value. Returns true if the
     * constraint is met, false otherwise.
     *
     * @param mixed $other value or object to evaluate
     * @return bool
     */
    protected function matches($other): bool
    {
        return \call_user_func($this->callback, $other);
    }
}
