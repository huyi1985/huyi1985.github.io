<?php

namespace Validator;

/**
 * Logical AND.
 */
class LogicalAnd extends LogicalConstraint
{

    /**
     * @var Constraint
     */
    private $failedConstraint = null;

    public function evaluate($other)
    {
        $success = true;

        foreach ($this->constraints as $constraint) {
            if (!$constraint->evaluate($other)) {
                $this->failedConstraint = $constraint;
                $success = false;

                break;
            }
        }

        return $success;

    }

    /**
     * Returns a string representation of the constraint.
     */
    public function failureDescription(): string
    {
        return $this->failedConstraint->failureDescription();
    }
}
