<?php

namespace Validator;

class RegularExpression extends Constraint
{
    /**
     * @var string
     */
    private $pattern;

    public function __construct(string $pattern)
    {
        parent::__construct();

        $this->pattern = $pattern;
    }

    public function failureDescription(): string
    {
        return \sprintf(
            '%s" does not match PCRE pattern %s',
            $this->other,
            $this->pattern
        );
    }

    protected function matches($other): bool
    {
        $matches = @\preg_match($this->pattern, $other);

        if (preg_last_error() === PREG_NO_ERROR) {
            return $matches > 0;
        }

        $pregDefinedConstants = get_defined_constants(true)['pcre'];
        throw new \RuntimeException(array_flip($pregDefinedConstants)[preg_last_error()]);
    }
}
