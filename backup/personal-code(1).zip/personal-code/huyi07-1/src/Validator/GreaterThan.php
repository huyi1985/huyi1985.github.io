<?php

namespace Validator;

/**
 * Constraint that asserts that the value it is evaluated for is greater
 * than a given value.
 */
class GreaterThan extends Constraint
{
    /**
     * @var float|int
     */
    private $value;

    /**
     * @param float|int $value
     */
    public function __construct($value)
    {
        if (!is_int($value) && !is_float($value)) {
            throw new \InvalidArgumentException("Only support int or float");
        }

        parent::__construct();

        $this->value = $value;
    }

    /**
     * Returns a string representation of the constraint.
     *
     */
    public function failureDescription(): string
    {
        return (string) $this->other . ' is not greater than ' . $this->value;
    }

    protected function matches($other): bool
    {
        if (!is_int($other) && !is_float($other)) {
            throw new \InvalidArgumentException("Only support int or float");
        }

        return $this->value < $other;
    }
}
