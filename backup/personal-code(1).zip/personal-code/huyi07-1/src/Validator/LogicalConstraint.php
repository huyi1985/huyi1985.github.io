<?php

namespace Validator;


abstract class LogicalConstraint extends Constraint
{
    /**
     * @var Constraint[]
     */
    protected $constraints = [];

    protected function __construct()
    {
        parent::__construct();
    }

    public static function fromConstraints(Constraint ...$constraints): self
    {
        $count = count($constraints);
        if ($count < 2) {
            throw new \LogicException("Need at least 2 constraints");
        }
        $constraint = new static;

        $constraint->constraints = \array_values($constraints);

        return $constraint;
    }

}