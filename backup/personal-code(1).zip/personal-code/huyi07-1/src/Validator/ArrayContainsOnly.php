<?php

namespace Validator;

class ArrayContainsOnly extends Constraint
{
    /**
     * @var IsType
     */
    private $isTypeConstraint;

    /**
     * @var string
     */
    private $type;

    /**
     * @var callable
     */
    private $callback;

    /**
     * @var mixed
     */
    private $failedElement;

    /**
     * @throws \PHPUnit\Framework\Exception
     */
    public function __construct(string $type, callable $callback = null)
    {
        parent::__construct();

        $this->isTypeConstraint = new IsType($type);
        $this->callback = $callback;

        $this->type = $type;

    }

    public function evaluate($other)
    {
        $this->other = $other;
        $success = true;

        try {
            array_walk_recursive($other, function ($element, $_) use (&$success) {
                if (!$this->isTypeConstraint->evaluate($element)) {
                    $this->failedElement = $element;
                    throw new \Exception($element);
                }

                if ($this->callback !== null && !call_user_func($this->callback, $element)) {
                    $this->failedElement = $element;
                    throw new \Exception();
                }
            });

        } catch (\Exception $e) {
            $success = false;
        }

        return $success;

    }

    /**
     * Returns a string representation of the constraint.
     */
    public function failureDescription(): string
    {
        return sprintf('%s does not contain only values of type "%s"'
            . ', or callback returns false at element "(%s) %s"',
            var_export($this->other, true),
            $this->type,
            gettype($this->failedElement),
            var_export($this->failedElement, true)
        );
    }
}
