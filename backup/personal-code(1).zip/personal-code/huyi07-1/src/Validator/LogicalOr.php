<?php
namespace Validator;

/**
 * Logical OR.
 */
class LogicalOr extends LogicalConstraint
{

    /**
     * @var Constraint[]
     */
    private $failedConstraints = [];

    public function evaluate($other)
    {
        $success = false;

        foreach ($this->constraints as $constraint) {
            if ($constraint->evaluate($other)) {
                $success = true;

                break;
            }

            $this->failedConstraints[] = $constraint;
        }

        return $success;

    }

    /**
     * Returns a string representation of the constraint.
     */
    public function failureDescription(): string
    {
        $text = '';

        foreach ($this->failedConstraints as $key => $constraint) {
            if ($key > 0) {
                $text .= ', and ';
            }

            $text .= $constraint->failureDescription();
        }

        return $text;
    }

}
