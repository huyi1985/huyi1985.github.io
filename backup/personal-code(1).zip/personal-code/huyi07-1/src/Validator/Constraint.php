<?php

namespace Validator;

/**
 * Abstract base class for constraints which can be applied to any value.
 */
abstract class Constraint
{
    protected $other;

    public function __construct()
    {
    }

    /**
     * Evaluates the constraint for parameter $other
     *
     * @param mixed $other value or object to evaluate
     *
     * @return bool
     */
    public function evaluate($other)
    {
        $this->other = $other;

        $success = false;

        if ($this->matches($other)) {
            $success = true;
        }

        return $success;
    }

    /**
     * Evaluates the constraint for parameter $other. Returns true if the
     * constraint is met, false otherwise.
     *
     * This method can be overridden to implement the evaluation algorithm.
     *
     * @param mixed $other value or object to evaluate
     * @return bool
     *
     * @codeCoverageIgnore
     */
    protected function matches($other): bool
    {
        return false;
    }

    /**
     * Returns the description of the failure
     *
     * The beginning of failure messages is "Failed asserting that" in most
     * cases. This method should return the second part of that sentence.
     *
     * To provide additional failure information additionalFailureDescription
     * can be used.
     *
     * @return string
     */
    public abstract function failureDescription(): string;
}
