<?php

namespace Validator;


class ArrayContains extends Constraint
{

    /**
     * @var array
     */
    private $array;

    /**
     * @var bool
     */
    private $recursive = false;

    public function __construct(array $array, bool $recursive = false)
    {
        parent::__construct();

        $this->array = $array;
        $this->recursive = $recursive;
    }

    public function failureDescription(): string
    {
        return var_export($this->array, true) . ' does not contain ' . $this->other;
    }

    protected function matches($other): bool
    {
        if ($this->recursive) {
            try {
                array_walk_recursive($this->array, function ($element) use ($other) {
                    if ($element === $other) {
                        throw new \Exception();
                    }
                });
            } catch (\Exception $e) {
                return true;
            }
        } else {
            foreach ($this->array as $element) {
                if ($element === $other) {
                    return true;
                }
            }
        }

        return false;
    }

}