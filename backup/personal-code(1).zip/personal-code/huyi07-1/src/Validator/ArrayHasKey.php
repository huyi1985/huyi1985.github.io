<?php

namespace Validator;

class ArrayHasKey extends Constraint
{
    /**
     * @var int|string
     */
    private $key;

    /**
     * @var bool
     */
    private $isRecursive = false;

    /**
     * @var self
     */
    private $nextConstraint = null;

    /**
     * @param int|string $key
     * @param bool $isRecursive
     * @param self|null $next @todo next
     */
    public function __construct($key, bool $isRecursive = false, Constraint $next = null)
    {
        parent::__construct();
        $this->key = $key;
        $this->isRecursive = $isRecursive;
        $this->nextConstraint = $next;
    }

    protected function matches($other): bool
    {
        $success = false;

        $found = null;
        if ($this->isRecursive) {
            try {
                array_walk_recursive($other, function($value, $key) use (&$found) {
                    if ($key === $this->key) {
                        $found = $value;
                        throw new \Exception();
                    }
                });

                return false;
            } catch (\Exception $e) {
                $success = true;
            }
        } else {
            if (\array_key_exists($this->key, $other)) {
                $success = true;
                $found = $other[$this->key];
            }
        }

        if ($found !== null && $this->nextConstraint !== null) {
            return $this->nextConstraint->evaluate($found);
        }

        return $success;
    }

    public function failureDescription(): string
    {
        $desc = var_export($this->other, true) . ' has not the key "' . $this->key . '"';
        if ($this->nextConstraint !== null) {
            $desc .= ', or "' . $this->key . '" => ' . $this->nextConstraint->failureDescription();
        }

        return $desc;
    }
}
