<?php

namespace Validator;

/**
 * Logical NOT.
 */
class LogicalNot extends Constraint
{
    /**
     * @var Constraint
     */
    private $constraint;

    public static function negate(string $string): string
    {
        $positives = [
            'contains ',
            'exists',
            'has ',
            'is ',
            'are ',
            'matches ',
            'starts with ',
            'ends with ',
            'reference ',
            'not not ',
        ];

        $negatives = [
            'does not contain ',
            'does not exist',
            'does not have ',
            'is not ',
            'are not ',
            'does not match ',
            'starts not with ',
            'ends not with ',
            'don\'t reference ',
            'not ',
        ];

        $negatedString = \str_replace(
            $negatives,
            $positives,
            $string
        );

        return $negatedString;
    }

    public function __construct(Constraint $constraint)
    {
        parent::__construct();

        $this->constraint = $constraint;
    }

    public function evaluate($other)
    {
        $success = !$this->constraint->evaluate($other);

        return $success;
    }


    public function failureDescription(): string
    {
        return self::negate($this->constraint->failureDescription());
    }
}
