<?php

use Validator\ArrayContains;
use Validator\ArrayContainsOnly;
use Validator\ArrayHasKey;
use Validator\Callback;
use Validator\GreaterThan;
use Validator\IsStringEqual;
use Validator\IsType;
use Validator\LessThan;
use Validator\LogicalAnd;
use Validator\LogicalNot;
use Validator\LogicalOr;
use Validator\RegularExpression;
use Validator\TraversableContains;

/**
 * Created by PhpStorm.
 * User: huyi07
 * Date: 2018/9/13
 * Time: 3:54 PM
 */

/*
 * 校验数据的类型是否合法，比如要求是bool, int, float, string, array, object类型中的某一个
 * 校验数据的值的范围是否合法，比如某个值要求 > 0且<100
 * 校验数据的值是否在某个列表内，比如某个数据只能取 ‘red’, ‘blue’, ‘green’这三个值之一
 *
 * 对于string类型的值，校验string的长度是否在某个区间，比如string长度必须大于0且小于20个字符
 * 对于string类型的值，校验string是否符合某个正则表达式，比如必须匹配’\w+’这样的正则
 *
 * 对于array类型的值，可以_递归地_校验其中的每个元素，满足某个校验规则，比如array中的元素都必须是int且大于0
 * 对于array类型的值，可以_递归地_校验其中的某个特定元素，满足某个校验规则，比如$arr[‘user_id’]必须是int且大于0
 * 对于array中的元素，支持可选字段的校验，比如$arr[‘enable’]字段如果存在，则必须为bool类型，如果不存在则不需要校验。

 * 支持用户自定义扩展校验规则，比如用户自己实现一个函数对某个字段进行校验
 */

class ValidatorTest extends \PHPUnit\Framework\TestCase
{

    /**
     * 校验数据的类型是否合法，比如要求是bool, int, float, string, array, object类型中的某一个
     */
    public function testValidate_IsType_int()
    {
        $intVar = 100;
        $errorMsg = null;
        $return = Validator::validate(new IsType(IsType::TYPE_INT), $intVar,$errorMsg);

        self::assertTrue($return);
        self::assertNull($errorMsg);
    }

    public function testValidate_IsType_string()
    {
        $floatValue = 3.14;
        $errorMsg = null;

        $return = Validator::validate(new IsType(IsType::TYPE_STRING), $floatValue,$errorMsg);

        self::assertFalse($return);
        self::assertContains(" is not ", $errorMsg);
    }

    /**
     * 校验数据的值的范围是否合法，比如某个值要求 > 0且<100
     */
    public function testValidate_InRange_int()
    {
        $intVar = 42;
        $errorMsg = null;

        $return = Validator::validate(LogicalAnd::fromConstraints(
            new GreaterThan(0),
            new LessThan(100)
        ), $intVar,$errorMsg);

        self::assertTrue($return);
        self::assertNull($errorMsg);
    }

    public function testValidate_NotInRange_int()
    {
        $intVar = 42;
        $errorMsg = null;

        $return = Validator::validate(LogicalAnd::fromConstraints(
            new GreaterThan(0),
            new LessThan(1)
        ), $intVar,$errorMsg);

        self::assertFalse($return);
        self::assertContains("not less than", $errorMsg);
    }

    public function testValidate_InRange_UnsupportedType()
    {
        $stringVar = "php";
        $errorMsg = null;

        try {
            $return = Validator::validate(LogicalAnd::fromConstraints(
                new GreaterThan(0),
                new LessThan(1)
            ), $stringVar, $errorMsg);
            self::fail("Should throw Exception");
        } catch (InvalidArgumentException $e) {
            self::assertContains("int or float", $e->getMessage());
        }
    }

    public function testValidate_InRange_UnsupportedType2()
    {
        $stringVar = "php";
        $errorMsg = null;

        try {
            $return = Validator::validate(LogicalAnd::fromConstraints(
                new GreaterThan('string'),
                new LessThan(1)
            ), $stringVar, $errorMsg);
            self::fail("Should throw Exception");
        } catch (InvalidArgumentException $e) {
            self::assertContains("int or float", $e->getMessage());
        }
    }

    /**
     * 校验数据的值是否在某个列表内，比如某个数据只能取 ‘red’, ‘blue’, ‘green’这三个值之一
     */
    public function testValidate_TraversableContains_withLogicalOr()
    {
        $stringVar = "php";
        $errorMsg = null;

        $return = Validator::validate(LogicalOr::fromConstraints(
            new IsStringEqual('red'),
            new IsStringEqual('blue'),
            new IsStringEqual('green')
        ), $stringVar, $errorMsg);

        self::assertFalse($return);
        self::assertContains(', and', $errorMsg);
        self::assertContains('is not equal', $errorMsg);
    }

    public function testValidate_ArrayContains_withLogicalOrIgnoreCase()
    {
        $stringVar = "red";
        $errorMsg = null;

        $return = Validator::validate(LogicalOr::fromConstraints(
            new IsStringEqual('ReD', true),
            new IsStringEqual('blue'),
            new IsStringEqual('green')
        ), $stringVar, $errorMsg);

        self::assertTrue($return);
        self::assertNull($errorMsg);
    }

    public function testValidate_ArrayContains()
    {
        $stringVar = "red";
        $errorMsg = null;

        $return = Validator::validate(new ArrayContains([
            'red', 'blue', 'green'
        ]), $stringVar, $errorMsg);

        self::assertTrue($return);
        self::assertNull($errorMsg);
    }

    public function testValidate_ArrayContains_Recursively()
    {
        $stringVar = "gray";
        $errorMsg = null;

        $return = Validator::validate(new ArrayContains([
            ['red'], [['blue']], 'green'
        ], true), $stringVar, $errorMsg);

        self::assertFalse($return);
        self::assertContains('does not contain', $errorMsg);
    }

    /**
     * 对于string类型的值，校验string的长度是否在某个区间，比如string长度必须大于0且小于20个字符
     */
    public function testValidate_strlenInRange()
    {
        $string = "hello world";
        $errorMsg = null;

        $return = Validator::validate(LogicalAnd::fromConstraints(
            new GreaterThan(0),
            new LessThan(20)
        ), strlen($string),$errorMsg);

        self::assertTrue($return);
        self::assertNull($errorMsg);
    }

    /**
     * 对于string类型的值，校验string是否符合某个正则表达式，比如必须匹配’\w+’这样的正则
     */
    public function testValidate_Regex()
    {
        $string = "helloWorld_01";
        $errorMsg = null;

        $return = Validator::validate(new RegularExpression('/^\w+_\d+$/'), $string,$errorMsg);

        self::assertTrue($return);
        self::assertNull($errorMsg);
    }

    public function testValidate_RegexFailed()
    {
        $string = "helloWorld_01";
        $errorMsg = null;

        $return = Validator::validate(new RegularExpression('/^\d+$/'), $string,$errorMsg);

        self::assertFalse($return);
        self::assertContains('does not match', $errorMsg);
    }

    public function testValidate_Regex_InvalidRegex()
    {
        $string = "helloWorld_01";
        $errorMsg = null;

        try {
            $return = Validator::validate(new RegularExpression('/[0-9]+?+/'), $string, $errorMsg);
            self::fail("Should throw Exception");
        } catch (RuntimeException $e) {
            self::assertStringStartsWith("PREG_", $e->getMessage());
        }
    }

    /**
     * 对于array类型的值，可以_递归地_校验其中的每个元素，满足某个校验规则，比如array中的元素都必须是int且大于0
     */
    public function testValidate_ArrayContainsOnly_NoCallback()
    {
        $arrayVar = [1, 2, 3];
        $errorMsg = null;

        $return = Validator::validate(new ArrayContainsOnly(IsType::TYPE_INT), $arrayVar, $errorMsg);

        self::assertTrue($return);
        self::assertNull($errorMsg);
    }

    public function testValidate_ArrayContainsOnly()
    {
        $arrayVar = [1, 2, 3, -1];
        $errorMsg = null;

        $return = Validator::validate(new ArrayContainsOnly(
            IsType::TYPE_INT,
            function($element) { return $element > 0; }
        ), $arrayVar, $errorMsg);

        self::assertFalse($return);
        self::assertContains('does not', $errorMsg);
    }

    public function testValidate_ArrayContainsOnly_Recursively()
    {
        $arrayVar = [1, 2, 3, -1, [2, 4, 6, 8]];
        $errorMsg = null;

        $return = Validator::validate(new ArrayContainsOnly(
            IsType::TYPE_INT
        ), $arrayVar, $errorMsg);

        self::assertTrue($return);
        self::assertNull($errorMsg);
    }

    public function testValidate_ArrayContainsOnly_Recursively_MixedType()
    {
        $arrayVar = [1, 3, 5, [2.0, 4.0, 6.0, 8.0]];
        $errorMsg = null;

        $return = Validator::validate(new ArrayContainsOnly(
            IsType::TYPE_INT
        ), $arrayVar, $errorMsg);

        self::assertFalse($return);
        self::assertContains('does not', $errorMsg);
    }

    /**
     * 对于array类型的值，可以_递归地_校验其中的某个特定元素，满足某个校验规则，比如$arr[‘user_id’]必须是int且大于0
     */
    public function testValidate_ArrayHasKey()
    {
        $arrayVar = ['user_id' => 100, 'name' => 'foo'];
        $errorMsg = null;

        $return = Validator::validate(new ArrayHasKey('user_id'), $arrayVar, $errorMsg);

        self::assertTrue($return);
        self::assertNull($errorMsg);
    }

    public function testValidate_ArrayHasNotKey()
    {
        $arrayVar = ['user_id' => 100, 'name' => 'foo'];
        $errorMsg = null;

        $return = Validator::validate(new ArrayHasKey('userId', true), $arrayVar, $errorMsg);

        self::assertFalse($return);
        self::assertContains('has not the key', $errorMsg);
    }

    public function testValidate_ArrayHasKey_withNextConstraint()
    {
        $arrayVar = ['user_id' => 100, 'name' => 'foo'];
        $errorMsg = null;

        $return = Validator::validate(new ArrayHasKey(
            'user_id',
            false,
            LogicalAnd::fromConstraints(new IsType(IsType::TYPE_INT), new GreaterThan(0))
        ), $arrayVar, $errorMsg);

        self::assertTrue($return);
        self::assertNull($errorMsg);
    }

    public function testValidate_ArrayHasKey_withNextFailedConstraint()
    {
        $arrayVar = ['user_id' => 100, 'name' => 'foo'];
        $errorMsg = null;

        $return = Validator::validate(new ArrayHasKey(
            'user_id',
            false,
            LogicalAnd::fromConstraints(new IsType(IsType::TYPE_INT), new GreaterThan(3000))
        ), $arrayVar, $errorMsg);

        self::assertFalse($return);
        self::assertContains('not', $errorMsg);
    }

    public function testValidate_ArrayHasKey_Recursively()
    {
        $arrayVar = ['user' => ['name' => 'foo', 'user_id' => 100]];
        $errorMsg = null;

        $return = Validator::validate(new ArrayHasKey('user_id', true), $arrayVar, $errorMsg);

        self::assertTrue($return);
        self::assertNull($errorMsg);
    }

    public function testValidate_ArrayHasKey_Recursively_withNextConstraints()
    {
        $arrayVar = ['user' => ['name' => ['first_name' => 'foo', 'last_name' => 'bar'], 'user_id' => 100]];
        $errorMsg = null;

        $return = Validator::validate(new ArrayHasKey(
            'user',
            false,
            new ArrayHasKey(
                'name',
                false,
                new ArrayHasKey('first_name')
            )
        ), $arrayVar, $errorMsg);

        self::assertTrue($return);
        self::assertNull($errorMsg);
    }

    /**
     * 对于array中的元素，支持可选字段的校验，比如$arr[‘enable’]字段如果存在，则必须为bool类型，如果不存在则不需要校验。
     */
    public function testValidate_OptionalKey()
    {
        $arrayVar = ['user' => ['name' => 'foobar', 'user_id' => 100], 'enable' => false];
        $errorMsg = null;

        $return = Validator::validate(LogicalOr::fromConstraints(
          new ArrayHasKey('enable', false, new IsType(IsType::TYPE_BOOL)),
          new LogicalNot(new ArrayHasKey('enable'))
        ), $arrayVar, $errorMsg);

        self::assertTrue($return);
        self::assertNull($errorMsg);
    }

    public function testValidate_LogicalNot()
    {
        $stringVar = 'abc';
        $errorMsg = null;

        $return = Validator::validate(new LogicalNot(new IsStringEqual($stringVar)), $stringVar, $errorMsg);

        self::assertFalse($return);
        self::assertNotContains('not', $errorMsg);
    }

    /**
     * 支持用户自定义扩展校验规则，比如用户自己实现一个函数对某个字段进行校验
     */
    public function testValidate_Callback()
    {
        $inputValue = 'value';
        $errorMsg = null;
        $apiReturnedJson = '{"code": 0, "data": {"key": "value"}}';

        $return = Validator::validate(new Callback(function($value) use ($apiReturnedJson) {
            $data = json_decode($apiReturnedJson, true);

            if ($data === null) {
                return false;
            }

            if (!isset($data['data']['key'])) {
                return false;
            }

            return $value == $data['data']['key'];
        }), $inputValue, $errorMsg);

        self::assertTrue($return);
    }

    public function testValidate_CallbackFailed()
    {
        $inputValue = 'value';
        $errorMsg = null;

        $return = Validator::validate(new Callback(function($value) {
            return false;
        }), $inputValue, $errorMsg);

        self::assertFalse($return);
        self::assertContains('not', $errorMsg);
    }

}
